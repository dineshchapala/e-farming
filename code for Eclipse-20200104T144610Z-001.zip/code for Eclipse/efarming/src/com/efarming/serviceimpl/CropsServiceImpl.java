package com.efarming.serviceimpl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Vector;

import com.efarming.bean.CourseBean;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.exception.DataNotFoundException;
import com.efarming.dao.CropsDaoI;
import com.efarming.dao.impl.CropsDaoImpl;
import com.efarming.exception.ConnectionException;
import com.efarming.servicei.CropsServiceI;

public class CropsServiceImpl implements CropsServiceI{
	String name="";
	boolean flag=false;
	CropsDaoI cdao=new CropsDaoImpl();
	Vector<CropBean> vdo=null;
	Vector<CourseBean> vcb=null;
	Vector<RegisterBean> vrb=null;
	public boolean addCrop(String name,FileInputStream fileInputStream, int length) throws ConnectionException {
		
		 try {
			 
			flag=cdao.addCrop(name,fileInputStream, length);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	
	
	public boolean addCropQuantity(CropBean cb) throws ConnectionException {
		
		 try {
			 
			flag=cdao.addCropQuantity(cb);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	public boolean addWholesalerOrder(CropBean cb) throws ConnectionException {
		
		 try {
			 
			flag=cdao.addWholesalerOrder(cb);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	public Vector<RegisterBean> addWholesalerTransaction(CropBean cb) throws ConnectionException {
		
		 try {
			 
			vrb=cdao.addWholesalerTransaction(cb);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return vrb;
	    }
	
	public boolean updateCropQuantity(CropBean cb) throws ConnectionException {
		
		 try {
			 
			flag=cdao.updateCropQuantity(cb);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	public boolean addCourse(String name) throws ConnectionException {
		
		 try {
			 
			flag=cdao.addCourse(name);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	public Vector<CourseBean> viewCourse() throws ConnectionException,DataNotFoundException {
		
		 try {
			 
			vcb=cdao.viewCourse();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 
			return vcb;
	    }

public Vector<CropBean> viewCrop(String path1)throws ConnectionException,DataNotFoundException{
		
		
		vdo=cdao.viewCrop(path1);
		if(vdo==null)
		{
			throw new ConnectionException();
			
		}
		else if (vdo.isEmpty()) {
			
			throw new DataNotFoundException();
			
		}
		return vdo;
		
	}

public Vector<CropBean> viewCropQuantity(String loginid)throws ConnectionException,DataNotFoundException{
	
	
	vdo=cdao.viewCropQuantity(loginid);
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}

public Vector<CropBean> viewCropQuantity(RegisterBean rb)throws ConnectionException,DataNotFoundException{
	
	
	vdo=cdao.viewCropQuantity(rb);
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}


public Vector<CropBean> viewCrop()throws ConnectionException,DataNotFoundException{
	
	
	vdo=cdao.viewCrop();
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}

public boolean deleteCrop(String cropid)throws ConnectionException{
	try{
	flag=cdao.deleteCrop(cropid);
	}catch (Exception e) {
		
		e.printStackTrace();
	}
	return flag;
	
}

public boolean deleteCropQuantity(String cropid)throws ConnectionException{
	try{
	flag=cdao.deleteCropQuantity(cropid);
	}catch (Exception e) {
		
		e.printStackTrace();
	}
	return flag;
	
}

public boolean deleteCourse(String courseid)throws ConnectionException{
	try{
	flag=cdao.deleteCourse(courseid);
	}catch (Exception e) {
		
		e.printStackTrace();
	}
	return flag;
	
}

public Vector<CropBean> viewPurchaseDetails(String loginid)throws ConnectionException,DataNotFoundException{
	
	
	vdo=cdao.viewPurchaseDetails(loginid);
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}
public Vector<CropBean> viewSalesDetails(String loginid)throws ConnectionException,DataNotFoundException{
	
	
	vdo=cdao.viewSalesDetails(loginid);
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}
}
