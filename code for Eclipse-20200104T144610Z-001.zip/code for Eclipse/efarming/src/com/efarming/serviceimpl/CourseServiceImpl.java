package com.efarming.serviceimpl;

import java.io.FileNotFoundException;
import java.util.Vector;

import com.efarming.bean.CourseBean;
import com.efarming.dao.CourseDaoI;
import com.efarming.dao.impl.CourseDaoImpl;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.servicei.CourseServiceI;

public class CourseServiceImpl implements CourseServiceI {
	
	Vector<CourseBean> vcb=null;
	boolean flag=false;
	CourseDaoI cdao=new CourseDaoImpl();
	public Vector<CourseBean> viewCourse(String user) throws ConnectionException,DataNotFoundException {
		
		 try {
			 
			vcb=cdao.viewCourse(user);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 
			return vcb;
	    }
	public Vector<CourseBean> viewSchedule() throws ConnectionException,DataNotFoundException {
		
		 try {
			 
			vcb=cdao.viewSchedule();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 
			return vcb;
	    }
	
	public Vector<CourseBean> viewCourseRequest() throws ConnectionException,DataNotFoundException {
		
		 try {
			 
			vcb=cdao.viewCourseRequest();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 
			return vcb;
	    }
	
	public boolean insertCourseEnroll(int cid,String userid) throws ConnectionException {
		
		 try {
			 
			flag=cdao.insertCourseEnroll(cid,userid);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	public boolean addCourseSchedule(CourseBean cb)throws ConnectionException {
		
		 try {
			 
			flag=cdao.addCourseSchedule(cb);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		 
			return flag;
	    }
	
	
}
