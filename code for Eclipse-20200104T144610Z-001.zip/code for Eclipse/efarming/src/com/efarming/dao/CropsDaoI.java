package com.efarming.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Vector;

import com.efarming.bean.CourseBean;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;

public interface CropsDaoI {
	
	 public boolean addCrop(String name,FileInputStream fileInputStream, int length)throws FileNotFoundException;
	 public boolean addCropQuantity(CropBean cb)throws FileNotFoundException;
	 public boolean addWholesalerOrder(CropBean cb)throws FileNotFoundException;
	 public Vector<RegisterBean> addWholesalerTransaction(CropBean cb)throws FileNotFoundException;
	 public boolean updateCropQuantity(CropBean cb)throws FileNotFoundException;
	 public Vector<CropBean> viewCrop(String path1);
	 public Vector<CropBean> viewCrop();
	 public Vector<CropBean> viewCropQuantity(String loginid);
	 public Vector<CropBean> viewCropQuantity(RegisterBean rb);
	 public boolean deleteCrop(String cropid);
	 public boolean deleteCropQuantity(String cropid);
	 public boolean deleteCourse(String courseid);
	 public boolean addCourse(String name)throws FileNotFoundException;
	 public Vector<CourseBean> viewCourse();
	 public Vector<CropBean> viewPurchaseDetails(String loginid);
	 public Vector<CropBean> viewSalesDetails(String loginid);
}
