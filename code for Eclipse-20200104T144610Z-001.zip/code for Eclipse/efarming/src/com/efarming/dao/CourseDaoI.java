package com.efarming.dao;

import java.io.FileNotFoundException;
import java.util.Vector;

import com.efarming.bean.CourseBean;

public interface CourseDaoI {
	
	 public Vector<CourseBean> viewCourse(String user);
	 public boolean insertCourseEnroll(int cid,String userid)throws FileNotFoundException;
	 public Vector<CourseBean> viewCourseRequest();
	 public boolean addCourseSchedule(CourseBean cb)throws FileNotFoundException;
	 public Vector<CourseBean> viewSchedule();
}
