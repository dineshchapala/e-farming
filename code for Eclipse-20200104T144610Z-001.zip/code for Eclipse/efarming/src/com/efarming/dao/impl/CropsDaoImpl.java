package com.efarming.dao.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.efarming.bean.CourseBean;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.dao.CropsDaoI;
import com.efarming.db.ConnectionFactory;

public class CropsDaoImpl implements CropsDaoI{

	Connection con;
	PreparedStatement pstmt,pstmt1,pstm1,pstm2,pstm3;
	Statement stmt,stmt1,stmt2,stmt3;
	ResultSet rs,rs1,rs2,rs3;
	public CropsDaoImpl()
	{
		con=ConnectionFactory.getConnection();
	}
	
	public boolean addCrop(String name,FileInputStream fileInputStream, int length)throws FileNotFoundException{
		 
		 
		 
		boolean flag = false;
		try {
			 pstmt = con.prepareStatement("INSERT INTO CROP VALUES((select nvl(max(cropid),0)+1 from crop),?,?)");
			pstmt.setString(1,name);
			pstmt.setBinaryStream(2, fileInputStream,length);
			int i = pstmt.executeUpdate();
			if(i>0)
				flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean addCropQuantity(CropBean cb)throws FileNotFoundException{
         boolean flag = false;
		try {
			int quantity=cb.getQuantity();
			int price=cb.getPrice();
			int cropid=cb.getCropid();
			String loginid=cb.getFarmerid();
			System.out.println("Loginid"+loginid);
			stmt=con.createStatement();
			rs=stmt.executeQuery("select nvl(max(AVAIL_QUANTITY),0)+1 from crop_farmer where cropid="+cropid+" and userid=(select userid from userdetails where loginid='"+loginid+"')");
			if(rs.next())
			{
				int qua=rs.getInt(1);
				if(qua==1)
				{
					pstmt = con.prepareStatement("INSERT INTO CROP_FARMER VALUES((select nvl(max(CROPSID_FORMER),0)+1 from crop_farmer),?,(select userid from userdetails where loginid=?),?,?,?)");
					pstmt.setInt(1,cropid);
					pstmt.setString(2,loginid);
					pstmt.setInt(3,quantity);
					pstmt.setInt(4,quantity);
					pstmt.setInt(5,price);
					
				}
				else
				{
				quantity+=qua-1;
				
				pstmt = con.prepareStatement("update crop_farmer set TOTAL_QUANITITY=?,AVAIL_QUANTITY=?,price=? where cropid=?");
				
				pstmt.setInt(1,quantity);
				pstmt.setInt(2,quantity);
				pstmt.setInt(3,price);
				pstmt.setInt(4,cropid);
				}
				
			}
			int i = pstmt.executeUpdate();
			if(i>0)
				flag = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean addWholesalerOrder(CropBean cb)throws FileNotFoundException{
        boolean flag = false;
		try {
			int avail=cb.getAvailquantity();
			int cropid=cb.getCropid();
			int farmerid=cb.getUserid();
			String wholesalerloginid=cb.getFarmerid();
			int req=cb.getOrderquantity();
			int price=cb.getPrice();
			int total=(req*price);
			System.out.println(total+"......"+req+"price"+price);
					pstmt = con.prepareStatement("INSERT INTO WHOLESALERS_ORDER VALUES((select nvl(max(orderid),0)+1 from WHOLESALERS_ORDER),?,?,?,sysdate,?,?)");
					pstmt.setInt(1,farmerid);
					pstmt.setInt(2,cropid);
					pstmt.setInt(3,req);
					pstmt.setInt(4,total);
					pstmt.setString(5,wholesalerloginid);
					int i = pstmt.executeUpdate();
					if(i>0){
						
						stmt=con.createStatement();
						int j=stmt.executeUpdate("update crop_farmer set avail_quantity=avail_quantity-"+req+" where cropid="+cropid+" and userid="+farmerid);
						if(j>0)
						{
							flag = true;	
						}
					}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public Vector<RegisterBean> addWholesalerTransaction(CropBean cb)throws FileNotFoundException{
        Vector<RegisterBean> vrb= new Vector<RegisterBean>();
        boolean flag=true;
		try {
			System.out.println("in dao....");
			//int cropid=cb.getCropid();
			int farmerid=cb.getUserid();
			String wholesalerloginid=cb.getFarmerid();
			String transaction=cb.getTransaction();
					pstmt = con.prepareStatement("INSERT INTO payment VALUES((select nvl(max(paymentid),0)+1 from payment),?,sysdate,?,(select userid from userdetails where loginid=?),(select max(orderid) from WHOLESALERS_ORDER))");
					pstmt.setInt(1,farmerid);
					pstmt.setString(2,transaction);
					pstmt.setString(3,wholesalerloginid);
					
					int i = pstmt.executeUpdate();
					if(i>0){
						flag=true;
						stmt=con.createStatement();
						rs=stmt.executeQuery("select u.firstname,u.lastname,a.area,a.district,a.state,a.city,a.houseno from userdetails u,address a where u.userid="+farmerid+" and a.userid="+farmerid);
						System.out.println("..........1"+rs);
						if(rs.next())
						{
							
							RegisterBean rb=new RegisterBean();
							rb.setFirstName(rs.getString(1));
							rb.setLastName(rs.getString(2));
							rb.setStreet(rs.getString(3));
							rb.setDistrict(rs.getString(4));
							rb.setState(rs.getString(5));
							rb.setCity(rs.getString(6));
							rb.setHouseNo(rs.getString(7));
							vrb.add(rb);									
						}
						
					}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}
		return vrb;
	}
	
	
	
	public boolean updateCropQuantity(CropBean cb)throws FileNotFoundException{
        boolean flag = false;
		try {
			int quantity=cb.getQuantity();
			int price=cb.getPrice();
			int cropid=cb.getCropid();
				pstmt = con.prepareStatement("update crop_farmer set AVAIL_QUANTITY=?,price=?,TOTAL_QUANITITY=? where CROPSID_FORMER=?");
				
				pstmt.setInt(1,quantity);
				pstmt.setInt(2,price);
				pstmt.setInt(3,quantity);
				pstmt.setInt(4,cropid);

			int i = pstmt.executeUpdate();
			if(i>0)
				flag = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public boolean addCourse(String name)throws FileNotFoundException{
		 
		 
		 
		boolean flag = false;
		try {
			System.out.println(name);
			 pstmt = con.prepareStatement("INSERT INTO Course VALUES((select nvl(max(courseid),0)+1 from course),?)");
			pstmt.setString(1,name);
		
			int i = pstmt.executeUpdate();
			if(i>0)
				flag = true;
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return flag;
	}
	
	public Vector<CourseBean> viewCourse()
	{
		Vector<CourseBean> vdo=null;
		
		
		try{
			stmt=con.createStatement();
			rs=stmt.executeQuery("select courseid,coursename from course");
			
			vdo=new Vector<CourseBean>();
			while(rs.next())
			{  
				CourseBean rb=new CourseBean();
								int courseid=rs.getInt(1);
								rb.setCourseid(courseid);
								rb.setCoursename(rs.getString(2));
								vdo.add(rb);
					 }		

		}
catch (SQLException e) {
	e.printStackTrace();
} 
catch(Exception e){
	
	e.printStackTrace();
}

finally
	{
	 try{
		 if(con!=null)
			 con.close();				 
	 }
	 catch(SQLException e){}
	}

return vdo;		
}
	
	
	 public Vector<CropBean> viewCrop(String path1)
		{
			Vector<CropBean> vdo=null;
			
			
			try{
				System.out.println("in  DAO");
				 
				stmt=con.createStatement();
				rs=stmt.executeQuery("select cropid,cropname,photo from crop");
				
				vdo=new Vector<CropBean>();
				while(rs.next())
				{  
									CropBean rb=new CropBean();
									int cropid=rs.getInt(1);
									rb.setCropid(cropid);
									rb.setCropname(rs.getString(2));
									Blob b=rs.getBlob(3);
									String path=path1;
									byte b1[] = b.getBytes(1,(int) b.length());
								    path=path +"/"+cropid+".jpg";
									OutputStream fout = new FileOutputStream(path);
									fout.write(b1);
									rb.setPhoto(path);
									vdo.add(rb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
	}
	 
	 
	 public Vector<CropBean> viewCropQuantity(String loginid)
		{
			Vector<CropBean> vdo=null;
			
			
			try{
				stmt=con.createStatement();
				rs=stmt.executeQuery("select CROPSID_FORMER,cropid,userid,TOTAL_QUANITITY,AVAIL_QUANTITY,price from crop_farmer where userid=(select userid from userdetails where loginid='"+loginid+"')");
				
				vdo=new Vector<CropBean>();
				while(rs.next())
				{  
					CropBean rb=new CropBean();
					int cropid=rs.getInt(2);
				     	stmt1=con.createStatement();
				     	rs1=stmt1.executeQuery("select cropname from crop where cropid="+cropid);
					          if(rs1.next())
					          {
					        	  rb.setCropname(rs1.getString(1));
					        	  
					          }
									
									int cropsid_farmer=rs.getInt(1);
			                        rb.setUserid(rs.getInt(3));
			                        rb.setQuantity(rs.getInt(4));
			                        rb.setAvailquantity(rs.getInt(5));
			                        rb.setPrice(rs.getInt(6));
									rb.setCropid(cropid);
									rb.setCropsid_farmer(cropsid_farmer);
									vdo.add(rb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
	}
	 
	 public Vector<CropBean> viewCropQuantity(RegisterBean rb)
		{
			Vector<CropBean> vdo=null;
			
			
			try{
				
				
				String state=rb.getState();
				String dist=rb.getDistrict();
				String crop=rb.getCropname();
				stmt=con.createStatement();
				rs=stmt.executeQuery("select CROPSID_FORMER,cropid,userid,TOTAL_QUANITITY,AVAIL_QUANTITY,price from crop_farmer where cropid=(select cropid from crop where cropname='"+crop+"')and userid in(select userid from address where state='"+state+"'and district='"+dist+"')");
				vdo=new Vector<CropBean>();
				while(rs.next())
				{  
					CropBean cb=new CropBean();
					        	  cb.setCropname(crop);
					        	  int cropsid_farmer=rs.getInt(1);
					        	  int cropid=rs.getInt(2);
			                        cb.setUserid(rs.getInt(3));
			                        cb.setQuantity(rs.getInt(4));
			                        cb.setAvailquantity(rs.getInt(5));
			                        cb.setPrice(rs.getInt(6));
									cb.setCropid(cropid);
									cb.setCropsid_farmer(cropsid_farmer);
									vdo.add(cb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
	}
	 
	 
	 public Vector<CropBean> viewCrop()
		{
			Vector<CropBean> vdo=null;
			
			
			try{
				System.out.println("in  DAO");
				 
				stmt=con.createStatement();
				rs=stmt.executeQuery("select cropid,cropname,photo from crop");
				
				vdo=new Vector<CropBean>();
				while(rs.next())
				{  
									CropBean rb=new CropBean();
									int cropid=rs.getInt(1);
									rb.setCropid(cropid);
									rb.setCropname(rs.getString(2));
									//Blob b=rs.getBlob(3);
									//String path=path1;
									//byte b1[] = b.getBytes(1,(int) b.length());
								   // path=path +"/"+cropid+".jpg";
									//OutputStream fout = new FileOutputStream(path);
									//fout.write(b1);
									//rb.setPhoto(path);
									vdo.add(rb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
	}
	 
	 public Vector<CropBean> viewPurchaseDetails(String loginid)
		{
			Vector<CropBean> vdo=null;
			
			
			try{
				System.out.println("in  DAO");
				 
				stmt=con.createStatement();
				rs=stmt.executeQuery("select userid,to_char(pay_date),paymentmode,paidby,orderidref from payment where paidby=(select userid from userdetails where loginid='"+loginid+"')");
				
				vdo=new Vector<CropBean>();
				while(rs.next())
				{  
									CropBean rb=new CropBean();
									int userid=rs.getInt(1);
									rb.setUserid(userid);
									rb.setPaiddate(rs.getString(2));
									rb.setPaymentmode(rs.getString(3));
									rb.setPaidby(rs.getInt(4));
									int orderid=rs.getInt(5);
									rb.setOrderid(rs.getInt(5));
						stmt1=con.createStatement();
                        rs1=stmt1.executeQuery("select ORDER_QUANTITY,totalprice,(select cropname from crop where cropid=(select cropid from WHOLESALERS_ORDER where orderid="+orderid+")) from WHOLESALERS_ORDER where orderid="+orderid);
						if(rs1.next())
						{
                        rb.setOrderquantity(rs1.getInt(1));
						rb.setPrice(rs1.getInt(2));
						rb.setCropname(rs1.getString(3));
                        vdo.add(rb);
                        }
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
	}
	 
	 public Vector<CropBean> viewSalesDetails(String loginid)
		{
			Vector<CropBean> vdo=null;
			
			
			try{
				System.out.println("in  DAO");
				 
				stmt=con.createStatement();
				rs=stmt.executeQuery("select userid,to_char(pay_date),paymentmode,paidby,orderidref from payment where userid=(select userid from userdetails where loginid='"+loginid+"')");
				
				vdo=new Vector<CropBean>();
				while(rs.next())
				{  
									CropBean rb=new CropBean();
									int userid=rs.getInt(1);
									rb.setUserid(userid);
									rb.setPaiddate(rs.getString(2));
									rb.setPaymentmode(rs.getString(3));
									rb.setPaidby(rs.getInt(4));
									int orderid=rs.getInt(5);
									rb.setOrderid(rs.getInt(5));
						stmt1=con.createStatement();
                     rs1=stmt1.executeQuery("select ORDER_QUANTITY,totalprice,(select cropname from crop where cropid=(select cropid from WHOLESALERS_ORDER where orderid="+orderid+")) from WHOLESALERS_ORDER where orderid="+orderid);
						if(rs1.next())
						{
                     rb.setOrderquantity(rs1.getInt(1));
						rb.setPrice(rs1.getInt(2));
						rb.setCropname(rs1.getString(3));
                     vdo.add(rb);
                     }
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
	}
	 
public boolean deleteCrop(String cropid){
	 boolean flag=false;
		try{	    		

        int queid=Integer.parseInt(cropid);
        stmt=con.createStatement();
        int i=stmt.executeUpdate("delete from crop where cropid="+queid);
        if(i>0)
        {
     	   
         	   flag=true;
         	 
	         
	          con.commit();
         	   }
       
	         else
	         {
	        	 flag=false;
	        	 con.rollback();
	         }
	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	        flag=false;
	    }  
	        catch (Exception se) 
	        {
	            se.printStackTrace();
	        }
	    
	    
	    finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}
	 return flag;
	 
}
	
public boolean deleteCropQuantity(String cropid){
	 boolean flag=false;
		try{	    		

       int cid=Integer.parseInt(cropid);
       stmt=con.createStatement();
       int i=stmt.executeUpdate("delete from crop_farmer where CROPSID_FORMER="+cid);
       if(i>0)
       {
    	   
        	   flag=true;
        	 
	         
	          con.commit();
        	   }
      
	         else
	         {
	        	 flag=false;
	        	 con.rollback();
	         }
	    } 
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	        flag=false;
	    }  
	        catch (Exception se) 
	        {
	            se.printStackTrace();
	        }
	    
	    
	    finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}
	 return flag;
	 
}

public boolean deleteCourse(String courseid){
	 boolean flag=false;
		try{	    			
       int cid=Integer.parseInt(courseid);
       
       stmt=con.createStatement();
       int i=stmt.executeUpdate("delete from course where courseid="+cid);
       if(i>0)
       {
    	   
        	   flag=true;
        	   con.commit();
        	   }
      
	         else
	         {
	        	 flag=false;
	        	 con.rollback();
	         }
	    
		}
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	        flag=false;
	    }  
	        catch (Exception se) 
	        {
	            se.printStackTrace();
	        }
	    
	    
	    finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}
	 return flag;
	 
}
public boolean deleteCours(String courseid){
	 boolean flag=false;
		try{	    			
      int cid=Integer.parseInt(courseid);
      stmt1=con.createStatement();
      int n=stmt1.executeUpdate("delete from course_enroll where courseid="+cid);
      if(n>0){
      stmt=con.createStatement();
      int i=stmt.executeUpdate("delete from course where courseid="+cid);
      if(i>0)
      {
   	   
       	   flag=true;
       	   con.commit();
       	   }
     
	         else
	         {
	        	 flag=false;
	        	 con.rollback();
	         }
	    } 
		}
	    catch (SQLException e) 
	    {
	        e.printStackTrace();
	        flag=false;
	    }  
	        catch (Exception se) 
	        {
	            se.printStackTrace();
	        }
	    
	    
	    finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}
	 return flag;
	 
}


}
