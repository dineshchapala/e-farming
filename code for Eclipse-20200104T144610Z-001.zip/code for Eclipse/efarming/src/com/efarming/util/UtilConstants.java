package com.efarming.util;

public class UtilConstants {
	
	//login
	
   public static final String _USERNAME="username";
   
   public static final String _PASSWORD="password";
   
   public static final String _ADMIN="ADMIN" ;
   
   public static final String _FARMER="FARMER" ;
   
 
   
   public static final String _WHOLESALER="WHOLESALER" ;
   
   public static final String _COMP_PROF="ComputerProfessional" ;
   
   
   
   public static final String _ADMIN_HOME="./jsps/adminhome.jsp" ;
   
   
   public static final String _FARMER_HOME="./jsps/farmerhome.jsp" ;
   
   public static final String _VIEW_FEEDBACK="./jsps/viewfeedback.jsp" ;
   
   public static final String _VIEW_CROPS="./jsps/viewcrops.jsp" ;
   
   public static final String _VIEW_FARMERCROPS="./jsps/viewfarmercrops.jsp" ;
   
   public static final String _VIEW_CROPS_FOR_WHOLESALER="./jsps/viewwholesalercrops.jsp" ;
   
   public static final String _VIEW_FARMER_CROP="./jsps/viewfarmercrop.jsp" ;
   
   public static final String _VIEW_CROP_AVILABILTY="./jsps/viewcropavailability.jsp" ;
   
   public static final String _VIEW_COURSE="./jsps/viewcourse.jsp" ;
   
   public static final String _VIEW_COURSE_FOR_SCHEDULE="./jsps/viewcourseforschedule.jsp" ;
   
   public static final String _VIEW_COURSE_REQUEST="./jsps/viewfarmercourserequest.jsp" ;
   
   public static final String _VIEW_SCHEDULE="./jsps/viewschedule.jsp" ;
   
   public static final String _VIEW_SCHEDULE_PROFFESTIONAL="./jsps/viewscheduleforprofessional.jsp" ;
   
   public static final String _VIEW_COURSES="./jsps/viewcoursebycompprof.jsp" ;
   
   public static final String _VIEW_COURSEREQUEST="./jsps/viewcourserequest.jsp" ;
   
   public static final String _VIEW_FARMER_COURSE="./jsps/viewfarmercourse.jsp" ;
   
   public static final String _VIEW_COMP_PROF="./jsps/viewcompprofessional.jsp" ;
   
   public static final String _VIEW_STATES="./jsps/viewstates.jsp" ;
   
   public static String _FARMER_LOGIN_PAGE="./jsps/farmerlogin.jsp";
   
   public static final String _VIEW_STATES_FOR_WHOLESALER="./jsps/viewstateswholesaler.jsp" ;
   
   public static final String _VIEW_DISTRICTS="./jsps/viewdistricts.jsp" ;
   
   public static final String _DISPLAY_ADDRESS="./jsps/displayaddress.jsp" ;
   
   public static final String _DISPLAY_PURCHASEDETAILS="./jsps/displaypurchasedetails.jsp" ;
   
   public static final String _DISPLAY_SALESDETAILS="./jsps/displaysalesdetails.jsp" ;
   
   public static final String _VIEW_DISTRICTS_WHOLESALER="./jsps/viewdistrictsforwholesaler.jsp" ;
   
   public static final String _VIEW_USER_RECORDS="./jsps/viewuserrecords.jsp" ;
   
   public static final String _WHOLESALER_HOME="./jsps/wholesaleshome.jsp" ;
   
   public static final String _COMP_PROF_HOME="./jsps/computerproffhome.jsp" ;
   
   public static Object _INVALID_USER="Invalid UserName and Password";

   public static String _LOGIN_FAILED_PAGE="./jsps/login.jsp";
   
   public static String _LOGIN_PAGE="./jsps/login.jsp";
   
   public static final String _LOGINUSER="user" ;
   
   public static final String _PASSWOED="password" ;
   
   public static final String _ROLE="role" ;
   
   public static final String _SERVER_BUSY="Server Busy plz Try After Some time";
   
   public static final String  _LOGOUT_SUCCESS="Logout Successfully";
   
   public static final String  _LOGOUT_FAILED="Logout Failed";
   
   
   
   //login
   
   
   public static final String _QUESTION_CHANGE="./jsps/Changequestion.jsp";
   
   public static final String _QUESTION_SUCCESS="Question Changed Successfully";
   
   public static final String _QUESTION_FAILED="Question Changing Failed";
   
   
    public static final String _RECOVER_PASSWORD="./jsps/recoverpassword.jsp";
   
   public static final String _RECOVER_PASSWORD_SUCCESS="Password Recovered Successfully......... password ---->";
   
   public static final String _RECOVER_PASSWORD_FAILED="Sorry... your not valid user";

   public static final String _NO_DATA="Sorry .. No Data ";
   
   public static final String _INVALIED_ENTRY="Invalied Entries Plz Provide Proper Data";
   
   public static final String _NO_DISTRICTS="Districts information not available please inform to admin";
   
  
   
   public static final String _NO_DATAA=" Try again... ";

   
   //Feedback
   
   public static final String _INSERT_FEEDBACK="Feed Back is Posted Successfully";
   
   public static final String _FEEDBACK_FAILED="Feedback posting Failed";
   
   public static final String _FEEDBACK_HOME="./jsps/Feedback.jsp";
   
   
    public static final String _CANCEL_FEEDBACK="Feed Back is Cancilation Successfully";
   
   public static final String _CANCEL_FEEDBACK_FAILED="Feedback Cancilation Failed";
   
   
  public static final String _VIEW_ALL_FEEDBACKS="Here is the Feedbacks from users";
   
   public static final String _ALL_FEEDBACKS_FAILED="No Feedbacks from Users";
   
   
   
   public static final String _DISPLAY_FEEDBACK_INFO="./jsps/ViewFeedBack.jsp";
   
   public static final String _DISPLAY_FEEDBACK="./jsps/ViewAllFeedback.jsp";
   
   public static final String _DISPLAY_FEEDBACK_ACTION="./DisplayFeedbackAction";
   
 
   //Registeration
   
   public static final String _USER_AVAILABLE="Available";
   
   public static final String _STATUS_NO="Request not conformed till now..";
   
   public static final String _STATUS_YES="Request was conformed.now you can do your Transactions";
   
   public static final String _DEPT_INSERTED="Department inserted successfully";
   
   public static final String _FEEDBACK_INSERTED="Feedback submited successfully";
   
   public static final String _QUERY_INSERTED="Query submited successfully";
   
   public static final String _FEEDBACK_NOTINSERTED="Feedback submited failed";
   
   public static final String _QUERY_NOTINSERTED="Query submited failed";
   
   public static final String _WORKER_REGISTRATION="./jsps/WorkerRegistrationForm.jsp";
   
   public static final String _USER_NO_AVAILABLE="Already Exists .. Enter proper userid";
   
   
}
