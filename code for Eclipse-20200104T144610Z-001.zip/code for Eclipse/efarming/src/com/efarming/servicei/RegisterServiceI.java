package com.efarming.servicei;



import java.util.Vector;

import com.efarming.exception.LoginException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.exception.ConnectionException;

public interface RegisterServiceI {
	 public boolean checkAvailability(String userid)throws ConnectionException;
	 public boolean registerCitizen(RegisterBean rb)throws ConnectionException;
	 public String passwordRecovery(RegisterBean rb)throws DataNotFoundException;
	 public String roleCheck(RegisterBean lb)throws LoginException,ConnectionException;
	 public Vector<RegisterBean> viewProfessional(String path1)throws ConnectionException,DataNotFoundException;
	 public boolean deleteCompprof(String userid)throws ConnectionException;
	 public Vector<RegisterBean> viewStates()throws ConnectionException,DataNotFoundException;
	 public Vector<RegisterBean> viewDistricts(String state)throws ConnectionException,DataNotFoundException;
	 public Vector<RegisterBean> viewUserRecord(String state,String dist,String role,String path1)throws ConnectionException,DataNotFoundException;

}
