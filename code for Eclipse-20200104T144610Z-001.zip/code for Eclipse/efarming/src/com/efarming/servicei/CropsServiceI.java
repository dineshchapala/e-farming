package com.efarming.servicei;

import java.io.FileInputStream;
import java.util.Vector;

import com.efarming.bean.CourseBean;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.exception.DataNotFoundException;
import com.efarming.exception.ConnectionException;

public interface CropsServiceI {
	
	 public boolean addCrop(String name,FileInputStream fileInputStream, int length)throws ConnectionException;
	 public boolean addCropQuantity(CropBean cb)throws ConnectionException;
	 public boolean addWholesalerOrder(CropBean cb)throws ConnectionException;
	 public Vector<RegisterBean> addWholesalerTransaction(CropBean cb)throws ConnectionException;
	 public boolean updateCropQuantity(CropBean cb)throws ConnectionException;
	 public Vector<CropBean> viewCrop(String path1)throws ConnectionException,DataNotFoundException;
	 public Vector<CropBean> viewCrop()throws ConnectionException,DataNotFoundException;
	 public Vector<CropBean> viewCropQuantity(String loginid)throws ConnectionException,DataNotFoundException;
	 public Vector<CropBean> viewCropQuantity(RegisterBean rb)throws ConnectionException,DataNotFoundException;
	 public boolean deleteCrop(String cropid)throws ConnectionException;
	 public boolean deleteCropQuantity(String cropid)throws ConnectionException;
	 public boolean deleteCourse(String Courseid)throws ConnectionException;
	 public boolean addCourse(String name)throws ConnectionException;
	 public Vector<CourseBean> viewCourse()throws ConnectionException,DataNotFoundException;
	 public Vector<CropBean> viewPurchaseDetails(String loginid)throws ConnectionException,DataNotFoundException;
	 public Vector<CropBean> viewSalesDetails(String loginid)throws ConnectionException,DataNotFoundException;
}
