package com.efarming.servicei;

import java.util.Vector;

import com.efarming.bean.CourseBean;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;

public interface CourseServiceI {
	
	 public Vector<CourseBean> viewCourse(String user)throws ConnectionException,DataNotFoundException;
	 public boolean insertCourseEnroll(int cid,String userid)throws ConnectionException;
	 public Vector<CourseBean> viewCourseRequest()throws ConnectionException,DataNotFoundException;
	 public boolean addCourseSchedule(CourseBean cb)throws ConnectionException;
	 public Vector<CourseBean> viewSchedule()throws ConnectionException,DataNotFoundException;
}
