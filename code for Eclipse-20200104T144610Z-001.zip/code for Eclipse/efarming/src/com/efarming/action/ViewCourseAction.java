package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CourseBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.util.UtilConstants;

public class ViewCourseAction extends HttpServlet {

	
	
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
          Vector<CourseBean> cb=null;
		 String path="";
		 HttpSession session=request.getSession();
		 String role=(String)session.getAttribute("role");
		 try {
				cb=new RegisterMgrDelegate().viewCourse();
				
			} catch (DataNotFoundException e) {
				System.out.println("....Servlet Action");
				
				request.setAttribute("status",UtilConstants._NO_DATA);
				path=UtilConstants._ADMIN_HOME;
				
			} catch (ConnectionException e) {
				
				request.setAttribute("status",UtilConstants._NO_DATA);
				path=UtilConstants._ADMIN_HOME;
			}
		   if(cb.isEmpty())
		{
			
			request.setAttribute("status",UtilConstants._NO_DATA);
				path=UtilConstants._ADMIN_HOME;
		}
			
		   else if(!cb.isEmpty())
		{
			     request.setAttribute("courses",cb);
			     if(role.equalsIgnoreCase("ComputerProfessional"))
			     {
			    	 path=UtilConstants._VIEW_COURSES; 
			    	 
			     }
			     else if(role.equalsIgnoreCase("ADMIN"))
				  {
			    	 path=UtilConstants._VIEW_COURSE;
				  }
		}
		
RequestDispatcher rd=request.getRequestDispatcher(path);
	
	        rd.forward(request, response);
	}

}

