package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.util.UtilConstants;

public class CheckUserAction extends HttpServlet {

	
	
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

boolean flag=false;
		
		String target="./jsps/registrationform.jsp";
		
		
		try{
			
			
			String userid=request.getParameter("userName");
			String role=request.getParameter("role");
			if(role.equalsIgnoreCase("ComputerProfessional"))
			{
				target="./jsps/computerprofregistrationform.jsp";
			}
			
			
			flag=new RegisterMgrDelegate().checkAvailability(userid);
			System.out.println(flag);
			if(flag==false){
				
				request.setAttribute("status", UtilConstants._USER_AVAILABLE);
			
			}
			else
			{
				
              request.setAttribute("status", UtilConstants._USER_NO_AVAILABLE);
			
			}
			}
		catch (Exception e) {
			
			e.printStackTrace();
			
			request.setAttribute("status", "Sorry.. Try again ...");
			
			
			
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
		
		
	}

	
}
