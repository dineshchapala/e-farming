package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.util.UtilConstants;

public class ViewUserRecordAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session=request.getSession();
		String role=(String)session.getAttribute("userrole");
		String state=request.getParameter("statename");
		String dist=request.getParameter("distname");
		System.out.println("  "+role+state+dist);
		String path="";
		Vector<RegisterBean> vb=null;
		
		try{
			
			try{
				 String path1=request.getRealPath("/images");
				vb=new RegisterMgrDelegate().viewUserRecord(state,dist,role,path1);
				
			}
			catch (ConnectionException e) {
				
				throw new ServletException("Connection Failed");
				}
			catch (DataNotFoundException e) {
				
				throw new ServletException("Data not Found");
				}
			
			if(!vb.isEmpty()){
				
				//request.setAttribute("status", UtilConstants._DEPT_OFFICERS_DETAILS);
				
				    request.setAttribute("user", vb);
					path=UtilConstants. _VIEW_USER_RECORDS;
				
			}	
			else if(vb.isEmpty())
			{
				request.setAttribute("status", UtilConstants._NO_DATA);
				path=UtilConstants._ADMIN_HOME;
				
			}
			
		}
		catch (Exception e) {
			
			request.setAttribute("status", UtilConstants._NO_DATA);
			path=UtilConstants._ADMIN_HOME;
		}
		RequestDispatcher rd=request.getRequestDispatcher(path);
		
		rd.forward(request, response);
	
}

}
