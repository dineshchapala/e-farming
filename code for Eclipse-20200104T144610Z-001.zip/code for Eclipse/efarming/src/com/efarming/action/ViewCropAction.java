package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.util.UtilConstants;

public class ViewCropAction extends HttpServlet {

	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Vector<CropBean> bb=null;
		  String path="";
		  String path1="";
		 try {
			 
			    path1=request.getRealPath("/images");
				bb=new RegisterMgrDelegate().viewCrop(path1);
				 if(bb==null)
					{
						
						request.setAttribute("status",UtilConstants._NO_DATA);
							path=UtilConstants._ADMIN_HOME;
					}
						
					   else if(!bb.isEmpty())
					{
						     request.setAttribute("trans",bb);
							path=UtilConstants._VIEW_CROPS;
					}
				
			} catch (DataNotFoundException e) {
				System.out.println("....Servlet Action");
				
				request.setAttribute("status",UtilConstants._NO_DATA);
				path=UtilConstants._ADMIN_HOME;
				
			} catch (ConnectionException e) {
				
				request.setAttribute("status",UtilConstants._NO_DATA);
				path=UtilConstants._ADMIN_HOME;
			}
		  finally{
		
 RequestDispatcher rd=request.getRequestDispatcher(path);
	
	        rd.forward(request, response);
	}
	}
}
