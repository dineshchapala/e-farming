package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.efarming.delegate.RegisterMgrDelegate;

public class DeleteCropQuantityAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cid=request.getParameter("cid");
		boolean flag=false;
		String path="";
		try{
			flag=new RegisterMgrDelegate().deleteCropQuantity(cid);
			if(flag==true){
				
				request.setAttribute("status", "Crop Deleted from Farmer list");
				
				path="./jsps/farmerhome.jsp";
				
				
			}
			else
			{
				
              request.setAttribute("status", "Deletion failed.. try later");
				
              path="./jsps/farmerhome.jsp";
				
			}
			}
		catch (Exception e) {
			
			
			
			request.setAttribute("status", "Deletion failed.. try later");
			
			path="./jsps/farmerhome.jsp";
			
		}
		RequestDispatcher rd=request.getRequestDispatcher(path);
		rd.forward(request, response);
	}

}
