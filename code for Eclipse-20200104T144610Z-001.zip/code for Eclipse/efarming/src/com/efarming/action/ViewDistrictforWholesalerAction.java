package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.util.UtilConstants;

public class ViewDistrictforWholesalerAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String state=request.getParameter("statename");
		 String path="";
			Vector<RegisterBean> vb=null;
			
			try{
				
				try{
					
					vb=new RegisterMgrDelegate().viewDistricts(state);
					
				}
				catch (ConnectionException e) {
					
					throw new ServletException("Connection Failed");
					}
				catch (DataNotFoundException e) {
					
					throw new ServletException("Data not Found");
					}
				
				if(!vb.isEmpty()){
					
					//request.setAttribute("status", UtilConstants._DEPT_OFFICERS_DETAILS);
					
					request.setAttribute("deptart", vb);
					request.setAttribute("statename",state);
					
						path=UtilConstants. _VIEW_DISTRICTS_WHOLESALER;
					
				}	
				else if(vb.isEmpty())
				{
					request.setAttribute("status", UtilConstants._NO_DATA);
					path=UtilConstants._WHOLESALER_HOME;
					
				}
				
			}
			catch (Exception e) {
				
				request.setAttribute("status", UtilConstants._NO_DATA);
				path=UtilConstants._WHOLESALER_HOME;
			}
			RequestDispatcher rd=request.getRequestDispatcher(path);
			
			rd.forward(request, response);
	}

}
