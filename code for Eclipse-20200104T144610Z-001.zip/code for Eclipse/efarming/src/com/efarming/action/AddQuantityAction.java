package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CropBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;

public class AddQuantityAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String loginid=(String)session.getAttribute("user");
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		int price=Integer.parseInt(request.getParameter("price"));
		int cropid=Integer.parseInt(request.getParameter("cname"));
		CropBean cb=new CropBean();
		boolean flag=false;
        String path="";
        try {
        	cb.setFarmerid((loginid));
        	cb.setQuantity(((quantity)));
        	cb.setCropid(cropid);
        	cb.setPrice(price);
        	
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			 flag =rmd.addCropQuantity(cb);
				if(flag){
					path="./jsps/farmerhome.jsp";
					request.setAttribute("status","Added successfull");
					
				}
				else {
					path="./jsps/farmerhome.jsp";
					request.setAttribute("status","Failed ... Try again");
				}
				
			} 
			 catch (ConnectionException ce) {
				
				throw new ServletException("Connection Failed");
				
			}
			 catch(Exception e){}
			    
			
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
		
	}

}
