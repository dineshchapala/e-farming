package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.util.UtilConstants;

public class PurchaseDetailsAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String loginid=(String)session.getAttribute("user");
		String role=(String)session.getAttribute("role");
		boolean flag=false;
		Vector<CropBean> rb=null;
        String path="";
        try {
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			rb =rmd.viewPurchaseDetails(loginid);
			
			/* if(flag)
			 {
				 path=UtilConstants. _DISPLAY_ADDRESS;
			 }
			 else
			 {
				 path=UtilConstants. _DISPLAY_ADDRESS;
			 }*/
				 
		 if(!rb.isEmpty()){
					
					System.out.println("... reere");
				         request.setAttribute("trans",rb);
						path=UtilConstants. _DISPLAY_PURCHASEDETAILS;
					
				}	
				else if(rb.isEmpty())
					
				{
					if(role.equalsIgnoreCase("WHOLESALER")){
					System.out.println("... ex");
					request.setAttribute("status", "No Transaction .. Try later");
					path=UtilConstants. _WHOLESALER_HOME;
					}
					else if(role.equalsIgnoreCase("FARMER")){
						System.out.println("... ex");
						request.setAttribute("status", "No Transaction ... Try later");
						path=UtilConstants. _FARMER_HOME;
						}
					
				}
				
				
			} 
			 catch (ConnectionException ce) {
				 if(role.equalsIgnoreCase("WHOLESALER")){
						System.out.println("... ex");
						request.setAttribute("status", "No Transaction .. Try later");
						path=UtilConstants. _WHOLESALER_HOME;
						}
						else if(role.equalsIgnoreCase("FARMER")){
							System.out.println("... ex");
							request.setAttribute("status", "No Transaction ... Try later");
							path=UtilConstants. _FARMER_HOME;
							}
				
				throw new ServletException("Connection Failed");
				
				
			}
			 catch(Exception e){
				 
				 if(role.equalsIgnoreCase("WHOLESALER")){
						System.out.println("... ex");
						request.setAttribute("status", "No Transaction .. Try later");
						path=UtilConstants. _WHOLESALER_HOME;
						}
						else if(role.equalsIgnoreCase("FARMER")){
							System.out.println("... ex");
							request.setAttribute("status", "No Transaction ... Try later");
							path=UtilConstants. _FARMER_HOME;
							}
			 }
			    
			finally{
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
	}
	}
}
