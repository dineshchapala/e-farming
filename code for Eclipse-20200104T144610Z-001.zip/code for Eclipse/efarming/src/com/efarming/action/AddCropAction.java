package com.efarming.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;

public class AddCropAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		boolean flag=false;
        String path="";
        DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
		fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
		String destinationDir = request.getSession().getServletContext().getRealPath("tmpImage");
		ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
		String name="";
		String type="";
		 try {
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			 List items = uploadHandler.parseRequest(request);
				Iterator itr = items.iterator();
				FileInputStream fileInputStream = null;
				int length = 0;
				while (itr.hasNext()) {
					FileItem item =(FileItem)itr.next();
					if (item.isFormField()) {
//						out.println("File Name = " + item.getFieldName()
//								+ ", Value = " + item.getString());	
						if(item.getFieldName().equals("name"))
							name = item.getString();
					} else {
						File file = new File(destinationDir, new File(item.getName()).getName());
						item.write(file);
						fileInputStream = new FileInputStream(file);
						length = (int) file.length();
						file.deleteOnExit();
						System.out.println(fileInputStream+"...."+length+"....."+destinationDir+"....."+uploadHandler+"-----"+fileItemFactory);
					
					}
				}
			flag =rmd.addCrop(name,fileInputStream,length);
			if(flag){
				path="./jsps/adminhome.jsp";
				request.setAttribute("status", "Added successfull");
				
			}
			else {
				path="./jsps/adminhome.jsp";
				request.setAttribute("status","Failed ... Try again");
			}
			
		} 
		 catch (ConnectionException ce) {
			
			throw new ServletException("Connection Failed");
			
		}
		 catch(Exception e){}
		    
		
		RequestDispatcher rd=request.getRequestDispatcher(path);
		rd.forward(request, response);
		
	}

}
