package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.LoginException;
import com.efarming.util.UtilConstants;
import com.efarming.bean.RegisterBean;

public class LoginAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session=request.getSession();
	     RegisterBean lb=new RegisterBean();
	     String username=request.getParameter("loginid");
	     lb.setUserid(username);
	     String password=request.getParameter("password");
	     lb.setPassword(password);
	     String target="";
	     String role="";
	     
	    try{	 
	           role=(String)new RegisterMgrDelegate().roleCheck(lb);
	           System.out.println("in LoginAction Role is.........."+role);
	           
	           if (role.equalsIgnoreCase(UtilConstants._ADMIN))
	       	{
	       		
	       		request.setAttribute("status","Welcome "+ username);
	       		
	       		target = UtilConstants._ADMIN_HOME;
	       		
	       		session.setAttribute(UtilConstants._LOGINUSER, username );
	       		session.setAttribute(UtilConstants._ROLE, role);
	       		session.setAttribute(UtilConstants._PASSWORD,password);
	       		
	       	}
	           
	           else if (role.equalsIgnoreCase(UtilConstants._WHOLESALER))
		       	{
		       		
		       		request.setAttribute("status","Welcome "+ username);
		       		
		       		target = UtilConstants._WHOLESALER_HOME;
		       		
		       		session.setAttribute(UtilConstants._LOGINUSER, username );
		       		session.setAttribute(UtilConstants._ROLE, role);
		       		session.setAttribute(UtilConstants._PASSWORD,password);
		       		
		       	}
	           else if (role.equalsIgnoreCase(UtilConstants._COMP_PROF))
		       	{
		       		
		       		request.setAttribute("status","Welcome "+ username);
		       		
		       		target = UtilConstants._COMP_PROF_HOME;
		       		
		       		session.setAttribute(UtilConstants._LOGINUSER, username );
		       		session.setAttribute(UtilConstants._ROLE, role);
		       		session.setAttribute(UtilConstants._PASSWORD,password);
		       		
		       	}
	       	
	       	else
	       	{
	       		System.out.println("Role"+role);
	       		
	       		
	       	request.setAttribute("status", UtilConstants._INVALID_USER);
	       		
	       	 target="./jsps/login1.jsp";
	       	}
	    
	}/*catch (ConnectionException e) {
		request.setAttribute("status", UtilConstants._INVALID_USER);
   		
   		target = UtilConstants._LOGIN_FAILED_PAGE;
		
		throw new ServletException("Server busy Plz Try after Some time");
	}
	catch (LoginException e) {
		
		request.setAttribute("status", UtilConstants._INVALID_USER);
 	    target=UtilConstants._LOGIN_FAILED_PAGE;
		
		}
		*/
catch (Exception e) {
	
		
			request.setAttribute("status", "Server busy Plz Try after Some time");
	       target="./jsps/home.jsp";
	
		
		}
	finally{

	RequestDispatcher rd = request.getRequestDispatcher(target);
	rd.forward(request, response);
	}	

}
}
