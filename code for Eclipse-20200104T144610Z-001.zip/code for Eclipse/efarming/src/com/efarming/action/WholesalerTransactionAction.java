package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.util.UtilConstants;

public class WholesalerTransactionAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String loginid=(String)session.getAttribute("user");
		String transaction=(request.getParameter("transaction"));
		int userid=Integer.parseInt(request.getParameter("userid"));
		int price=Integer.parseInt(request.getParameter("price"));
		System.out.println(userid+""+transaction);
		//int cropid=Integer.parseInt(request.getParameter("cropid"));
		CropBean cb=new CropBean();
		boolean flag=false;
		Vector<RegisterBean> rb=null;
        String path="";
        try {
        	System.out.println("......");
        	cb.setFarmerid((loginid));
        	cb.setTransaction(transaction);
        	//cb.setCropid(cropid);
        	cb.setUserid(userid);
        	cb.setPrice(Integer.parseInt(request.getParameter("price")));
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			rb =rmd.addWholesalerTransaction(cb);
			
			/* if(flag)
			 {
				 path=UtilConstants. _DISPLAY_ADDRESS;
			 }
			 else
			 {
				 path=UtilConstants. _DISPLAY_ADDRESS;
			 }*/
				 
		 if(!rb.isEmpty()){
					
					System.out.println("... reere");
				         request.setAttribute("trans",rb);
						path=UtilConstants. _DISPLAY_ADDRESS;
					
				}	
				else if(rb.isEmpty())
				{
					System.out.println("... ex");
					request.setAttribute("status", "Transaction fail Try later");
					path=UtilConstants. _WHOLESALER_HOME;
					
				}
				
				
			} 
			 catch (ConnectionException ce) {
				
				 request.setAttribute("status", " Try later");
					path=UtilConstants. _WHOLESALER_HOME;
				
				
			}
			 catch(Exception e){
				 request.setAttribute("status", " No Data Try later");
					path=UtilConstants. _WHOLESALER_HOME;
			 }
			    
			
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
	}

}
