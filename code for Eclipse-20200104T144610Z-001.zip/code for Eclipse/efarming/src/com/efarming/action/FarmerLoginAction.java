package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.exception.LoginException;
import com.efarming.util.UtilConstants;

public class FarmerLoginAction extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session=request.getSession();
	     RegisterBean lb=new RegisterBean();
	     String username=request.getParameter("loginid");
	     lb.setUserid(username);
	     String password=request.getParameter("password");
	     lb.setPassword(password);
	     String target=UtilConstants._FARMER_LOGIN_PAGE;
	     String role="";
	     
	    try{	 
	           role=(String)new RegisterMgrDelegate().roleCheck(lb);
	           System.out.println("in LoginAction Role is.........."+role);
	           
	        
	        if (role.equalsIgnoreCase(UtilConstants._FARMER))
		       	{
		       		
		       		request.setAttribute("status","Welcome "+ username);
		       		
		       		target = UtilConstants._FARMER_HOME;
		       		
		       		session.setAttribute(UtilConstants._LOGINUSER, username );
		       		session.setAttribute(UtilConstants._ROLE, role);
		       		session.setAttribute(UtilConstants._PASSWORD,password);
		       		
		       	}
	          
	       	else
	       	{
	       		request.setAttribute("status", UtilConstants._INVALID_USER);
	       		
	       		target = UtilConstants._FARMER_LOGIN_PAGE;
	       	}
	}catch (ConnectionException e) {
		
		request.setAttribute("status", UtilConstants._INVALID_USER);
  		
  		target = UtilConstants._FARMER_LOGIN_PAGE;
	}
	catch (LoginException e) {
		
		request.setAttribute("status", UtilConstants._INVALID_USER);
	    target=UtilConstants._FARMER_LOGIN_PAGE;
		
		}
  catch (Exception e) {
		
		request.setAttribute("status", "Server busy Plz Try after Some time");
	    target=UtilConstants._FARMER_LOGIN_PAGE;
		
		}
	finally{
		
	RequestDispatcher rd = request.getRequestDispatcher(target);
	rd.forward(request, response);
	}	

}

}
