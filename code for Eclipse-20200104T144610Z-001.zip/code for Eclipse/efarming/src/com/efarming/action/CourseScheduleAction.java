package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CourseBean;
import com.efarming.bean.CropBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;

public class CourseScheduleAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String loginid=(String)session.getAttribute("user");
		String course=request.getParameter("course");
		String date=request.getParameter("date");
		String time=request.getParameter("time");
		String place=request.getParameter("place");
		CourseBean cb=new CourseBean();
		boolean flag=false;
        String path="";
        try {
        	cb.setCoursename(course);
        	cb.setDate(date);
        	cb.setTime(time);
        	cb.setArea(place);
        	cb.setUsername(loginid);
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			 flag =rmd.addCourseSchedule(cb);
				if(flag){
					path="./jsps/computerproffhome.jsp";
					request.setAttribute("status","Scheduled");
					
				}
				else {
					path="./jsps/computerproffhome.jsp";
					request.setAttribute("status","Failed ... Try again");
				}
				
			} 
			 catch (ConnectionException ce) {
				
				throw new ServletException("Connection Failed");
				
			}
			 catch(Exception e){}
			    
			
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
	}

}
