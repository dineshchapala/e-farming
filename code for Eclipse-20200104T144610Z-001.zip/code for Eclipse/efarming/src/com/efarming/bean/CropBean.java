package com.efarming.bean;

public class CropBean {
	
	private int cropid;
	private int orderid;
	private String cropname;
	private String photo;
	private String farmerid;
	private String transaction;
	private int quantity;
	private int price;
	private int availquantity;
	private int orderquantity;
	private int cropsid_farmer;
	private int userid;
	private String paiddate;
	private int paidby;
	private String paymentmode;
	public String getPaiddate() {
		return paiddate;
	}
	public void setPaiddate(String paiddate) {
		this.paiddate = paiddate;
	}
	public String getFarmerid() {
		return farmerid;
	}
	public void setFarmerid(String farmerid) {
		this.farmerid = farmerid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCropid() {
		return cropid;
	}
	public void setCropid(int cropid) {
		this.cropid = cropid;
	}
	public String getCropname() {
		return cropname;
	}
	public void setCropname(String cropname) {
		this.cropname = cropname;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public int getAvailquantity() {
		return availquantity;
	}
	public void setAvailquantity(int availquantity) {
		this.availquantity = availquantity;
	}
	public int getCropsid_farmer() {
		return cropsid_farmer;
	}
	public void setCropsid_farmer(int cropsid_farmer) {
		this.cropsid_farmer = cropsid_farmer;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getOrderquantity() {
		return orderquantity;
	}
	public void setOrderquantity(int orderquantity) {
		this.orderquantity = orderquantity;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getPaymentmode() {
		return paymentmode;
	}
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
	public int getPaidby() {
		return paidby;
	}
	public void setPaidby(int paidby) {
		this.paidby = paidby;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

}
