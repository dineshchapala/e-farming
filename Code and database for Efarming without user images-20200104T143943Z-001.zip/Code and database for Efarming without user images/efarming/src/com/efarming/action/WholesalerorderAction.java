package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CropBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;

public class WholesalerorderAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String loginid=(String)session.getAttribute("user");
		int quantity=Integer.parseInt(request.getParameter("avail"));
		int orderedquantity=Integer.parseInt(request.getParameter("reqired"));
		int userid=Integer.parseInt(request.getParameter("userid"));
		int price=Integer.parseInt(request.getParameter("price"));
		System.out.println(userid);
		int cropid=Integer.parseInt(request.getParameter("cropid"));
		CropBean cb=new CropBean();
		boolean flag=false;
        String path="";
        try {
        	cb.setFarmerid((loginid));
        	cb.setAvailquantity((quantity));
        	cb.setOrderquantity(orderedquantity);
        	cb.setCropid(cropid);
        	cb.setUserid(userid);
        	cb.setPrice(Integer.parseInt(request.getParameter("price")));
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			 flag =rmd.addWholesalerOrder(cb);
				if(flag){
					path="./jsps/wholesalestransaction.jsp?userid="+userid+"&reqorder="+orderedquantity+"&price="+price;
					request.setAttribute("status","Money Transaction ");
					
				}
				else {
					path="./jsps/wholesaleshome.jsp";
					request.setAttribute("status","Failed ... Try again");
				}
				
			} 
			 catch (ConnectionException ce) {
				
				throw new ServletException("Connection Failed");
				
			}
			 catch(Exception e){}
			    
			
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
		
	}

}
