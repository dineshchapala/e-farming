package com.efarming.action;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.disk.DiskFileItemFactory;

import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;

public class RegistrationAction extends HttpServlet {

	
	
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		boolean flag=false;
        String target="";
		RegisterBean rb=new RegisterBean();
		
		 try {
			 
			/* DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
				fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
				String destinationDir = request.getSession().getServletContext()
						.getRealPath("tmpImage");
						*/
			 
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate();
			// BeanUtils.populate(rb, map);
			 rb.setUserName(request.getParameter("userName"));
			 rb.setPassword(request.getParameter("password"));
			 
			 rb.setSquest(request.getParameter("squest"));
			 rb.setSecrete(request.getParameter("secrete"));
			 rb.setRole(request.getParameter("role"));
			 String role=request.getParameter("role");
			 System.out.println("....Role"+request.getParameter(" role")+role);
			 rb.setEmail(request.getParameter("email"));
			 rb.setFirstName(request.getParameter("firstName"));
			 rb.setLastName(request.getParameter("lastName"));
			 rb.setGender(request.getParameter("gender"));
			 rb.setDob(request.getParameter("dob"));
			 rb.setHouseNo(request.getParameter("houseNo"));
			 //rb.setWardNo(request.getParameter("wardno"));
			 rb.setStreet(request.getParameter("street"));
			 //rb.setDesignation(request.getParameter("designation"));
			 
			 rb.setPhoneNo(request.getParameter("phoneNo"));
			 rb.setDistrict(request.getParameter("district"));
			 rb.setState(request.getParameter("state"));
			 rb.setCountry(request.getParameter("country"));
			 rb.setPin(request.getParameter("pin"));
			 rb.setCity(request.getParameter("city"));
			 //rb.setPhoto(request.getParameter("photo"));
			 flag=rmd.registerCitizen(rb);
			 if(flag){
				 if(role.equalsIgnoreCase("ComputerProfessional"))
					{
						target="./jsps/adminhome.jsp";
						 request.setAttribute("status","Registeration is successfull");
					}
				 else if(role.equalsIgnoreCase("FARMER"))
					{
						target="./jsps/login.jsp";
						 request.setAttribute("status","Registeration is successfull");
					}
				 else
					 {
					 target="./jsps/login1.jsp";
				     request.setAttribute("status","Registeration is successfull");
				     System.out.println("role"+role);
					 }

				 
			}
			else {
				
				
				if(role.equalsIgnoreCase("ComputerProfessional"))
				{
					target="./jsps/adminhome.jsp";
					 request.setAttribute("status","Registeration Failed");
				}
			 else
				 {
				 target="./jsps/home.jsp";
			     request.setAttribute("status","Registeration Failed");
				 }
			}	 
			
		} 	 
		 catch (ConnectionException ce) {
			 
			 target="./jsps/home.jsp";
		     request.setAttribute("status","Registeration Failed");	
		}
		    
		finally{
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
		}
	}

}
