package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class I18NServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;

		public void doGet(HttpServletRequest req, HttpServletResponse res)
				throws ServletException, IOException {
			String cc = req.getParameter("country");
			String ln = req.getParameter("language");

			Locale l = null;
			if (cc == null)
				l = new Locale(ln);
			else
				l = new Locale(ln, cc);

			ResourceBundle rb = ResourceBundle.getBundle("ApplicationResources", l);
			System.out.println("Resource Bundle "+rb);
			HttpSession session = req.getSession();
			session.setAttribute("resource", rb);
			ResourceBundle rb1 = (ResourceBundle) session.getAttribute("resource");
			System.out.println("Resource Bundle one:"+rb1);
			RequestDispatcher rd = req.getRequestDispatcher("./jsps/farmerlogin.jsp");
			rd.forward(req, res);
		}// end service
	}// end class
