package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.efarming.bean.CropBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.ConnectionException;
import com.efarming.util.UtilConstants;

public class ViewSalesDetailsAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		HttpSession session = request.getSession();
		String loginid=(String)session.getAttribute("user");
		boolean flag=false;
		Vector<CropBean> rb=null;
        String path="";
        try {
			 RegisterMgrDelegate rmd=new RegisterMgrDelegate(); 
			  rb =rmd.viewSalesDetails(loginid);
			if(rb.isEmpty())
				{
					
					request.setAttribute("status", "No Transaction ... Try later");
					path=UtilConstants._FARMER_HOME;
					
				}
				else if(!rb.isEmpty()){
					
					
			         request.setAttribute("trans",rb);
					path=UtilConstants. _DISPLAY_SALESDETAILS;
				
			}
				
				
			} 
			 catch (ConnectionException ce) {
				
				 request.setAttribute("status", " Try later");
					path=UtilConstants._FARMER_HOME;
				
				
			}
			 catch(Exception e){
				 request.setAttribute("status", "No Data.. Try later");
					path=UtilConstants. _FARMER_HOME;
			 }
			    
			
			RequestDispatcher rd=request.getRequestDispatcher(path);
			rd.forward(request, response);
		
		
		
	}

}
