package com.efarming.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;



public class RegisterAction extends HttpServlet {

	
	private static final long serialVersionUID = 1L;

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		boolean flag=false;
        String target="";
		RegisterBean rb=new RegisterBean();
		RegisterMgrDelegate rmd=new RegisterMgrDelegate();
		DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
		fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
		String destinationDir = request.getSession().getServletContext().getRealPath("tmpImage");
		ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
		String name="";
		String type="";
		try {
			List items = uploadHandler.parseRequest(request);
			Iterator itr = items.iterator();
			FileInputStream fileInputStream = null;
			int length = 0;
			while (itr.hasNext()) {
				FileItem item = (FileItem) itr.next();
				if (item.isFormField()) {
//					out.println("File Name = " + item.getFieldName()
//							+ ", Value = " + item.getString());	
					if(item.getFieldName().equals("userName"))
						name = item.getString();
					if(item.getFieldName().equals("password"))
						type = item.getString();
					System.out.println("name and password"+name+type);
				} else {
					File file = new File(destinationDir, new File(item.getName()).getName());
					item.write(file);
					fileInputStream = new FileInputStream(file);
					length = (int) file.length();
					file.deleteOnExit();
				}
			}
			 flag = rmd.registerCitizen(rb);
			 if(flag == true)
			 System.out.println("Data Stored Successfully");
			 else {
			 System.out.println("Data Storage Failed");
			 }
		} catch (FileUploadException ex) {
			log("Error encountered while parsing the request", ex);
		} catch (Exception ex) {
			log("Error encountered while uploading file", ex);
		}
	}
}

