package com.efarming.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.efarming.bean.RegisterBean;
import com.efarming.delegate.RegisterMgrDelegate;
import com.efarming.exception.DataNotFoundException;
import com.efarming.util.UtilConstants;

public class ChangePasswordAction extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			
		
		RequestDispatcher rd=null;

		String pass="";
		String path="";
		
	RegisterBean rb=new RegisterBean();
		
		
		
	 
		
	try{
		
		try{
			rb.setUserName(request.getParameter("userName"));
			rb.setPassword(request.getParameter("oldpassword"));
			rb.setNewpassword(request.getParameter("newpassword"));
		    System.out.println(".."+request.getParameter("userName")+".."+request.getParameter("oldpassword")+".."+request.getParameter("newpassword"));
	
		    
		    
		          
		  pass=new RegisterMgrDelegate().passwordChange(rb);
		    	
	     System.out.println("password.........>"+pass);
		
	}
	    catch (DataNotFoundException ce) {
		throw new ServletException("server busy please try again");
	    }
	    
	   if(pass==null||pass=="")
	   {
		   
         request.setAttribute("status","Password not Changed");
		   
		   path=UtilConstants._CHANGE_PASSWORD;
		   
		   
		  
		   
		    }
	   else{
           request.setAttribute("status", UtilConstants._CHANGE_PASSWORD_SUCCESS+pass);
		   
		   path=UtilConstants._CHANGE_PASSWORD;
		   System.out.println("password.........>"+pass);
		   }
		    	
		
		
	}
	catch (Exception e) {
		e.printStackTrace();
		
		
		request.setAttribute("status", "INVALID ENTRIES");
		   
		    path = UtilConstants._CHANGE_PASSWORD;
		
}
	
	rd=request.getRequestDispatcher(path);
	
	rd.forward(request, response);

}
		
	}

