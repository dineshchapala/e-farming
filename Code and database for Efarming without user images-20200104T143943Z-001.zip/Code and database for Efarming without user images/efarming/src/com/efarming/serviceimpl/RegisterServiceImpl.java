package com.efarming.serviceimpl;
import java.io.FileNotFoundException;
import java.util.Vector;


import com.efarming.exception.LoginException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.exception.ConnectionException;
import com.efarming.dao.RegisterDaoI;
import com.efarming.dao.impl.RegisterDaoImpl;
import com.efarming.servicei.RegisterServiceI;

public class RegisterServiceImpl implements RegisterServiceI{
	
	boolean flag=false;
	Vector<RegisterBean> vdo=null;
	RegisterDaoI rdao=new RegisterDaoImpl();
	public boolean checkAvailability(String userid){
		 
		 flag=rdao.checkAvailability(userid);
		 
		 
			return flag;
		 
	 }
	public boolean registerCitizen(RegisterBean rb) throws ConnectionException {
		
		 try {
			 System.out.println("in service");
			flag=rdao.registerCitizen(rb);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
			return flag;
	    }
	
	
	public String passwordRecovery(RegisterBean rb)throws DataNotFoundException{
		 
		 String password=rdao.passwordRecovery(rb);
		 System.out.println("--------"+password);
		 
		 if(password==null)
			{
				
				throw new DataNotFoundException();
				
			}
			return password;
		 
		 
	}
	public String passwordChange(RegisterBean rb)throws DataNotFoundException{
		 
		 String password=rdao.passwordChange(rb);
		 System.out.println("--------"+password);
		 
		 if(password==null)
			{
				
				throw new DataNotFoundException();
				
			}
			return password;
		 
		 
	}
	
	public String roleCheck(RegisterBean lb)throws LoginException,ConnectionException{
		
		  
		String role="";
		 role=rdao.roleCheck(lb);
		 
		 if(role==null){
			 
			 throw new ConnectionException();
			 
			 
		 }
		 else if (lb.getUserid()==null || lb.getPassword()==null) {
			 
			 throw new ConnectionException();
			
		}
		 
		 return role;


	}
public Vector<RegisterBean> viewProfessional(String path1)throws ConnectionException,DataNotFoundException{
		
		
		vdo=rdao.viewProfessional(path1);
		if(vdo==null)
		{
			throw new ConnectionException();
			
		}
		else if (vdo.isEmpty()) {
			
			throw new DataNotFoundException();
			
		}
		return vdo;
		
	}

public Vector<RegisterBean> viewStates()throws ConnectionException,DataNotFoundException{
	
	
	vdo=rdao.viewStates();
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}

public Vector<RegisterBean> viewDistricts(String state)throws ConnectionException,DataNotFoundException{
	
	
	vdo=rdao.viewDistricts(state);
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}
public Vector<RegisterBean> viewUserRecord(String state,String dist,String role,String path1)throws ConnectionException,DataNotFoundException{
	vdo=rdao.viewUserRecord(state,dist,role,path1);
	if(vdo==null)
	{
		throw new ConnectionException();
		
	}
	else if (vdo.isEmpty()) {
		
		throw new DataNotFoundException();
		
	}
	return vdo;
	
}

public boolean deleteCompprof(String userid)throws ConnectionException{
	try{
	flag=rdao.deleteCompprof(userid);
	}catch (Exception e) {
		
		e.printStackTrace();
	}
	return flag;
	
}
	
}
