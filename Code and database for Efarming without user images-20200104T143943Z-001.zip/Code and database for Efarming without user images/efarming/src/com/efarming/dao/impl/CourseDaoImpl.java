package com.efarming.dao.impl;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import com.efarming.bean.CourseBean;
import com.efarming.dao.CourseDaoI;
import com.efarming.db.ConnectionFactory;
import com.efarming.util.DateWrapper;

public class CourseDaoImpl implements CourseDaoI{
	
	Connection con;
	PreparedStatement pstmt,pstmt1,pstm1,pstm2,pstm3;
	Statement stmt,stmt1,stmt2,stmt3;
	ResultSet rs,rs1,rs2,rs3;
	public CourseDaoImpl(){
		con=ConnectionFactory.getConnection();
	}
	public Vector<CourseBean> viewCourse(String user)
	{
		Vector<CourseBean> vdo=null;
		
		
		try{
			
			vdo=new Vector<CourseBean>();
			
				stmt1=con.createStatement();
				rs1=stmt1.executeQuery("select firstname,lastname,area,city,district from address,userdetails where userdetails.loginid='"+user+"' and address.userid=(select userid from userdetails where loginid='"+user+"')");
				if(rs1.next())
				{  
				CourseBean rb=new CourseBean();
							
								rb.setUsername(rs1.getString(1));
								rb.setLastname(rs1.getString(2));
								rb.setArea(rs1.getString(3));
								rb.setCity(rs1.getString(4));
								rb.setDistrict(rs1.getString(5));
								vdo.add(rb);
					 }		

		}
catch (SQLException e) {
	e.printStackTrace();
} 
catch(Exception e){
	
	e.printStackTrace();
}

finally
	{
	 try{
		 if(con!=null)
			 con.close();				 
	 }
	 catch(SQLException e){}
	}

return vdo;		
}
	
	public Vector<CourseBean> viewSchedule()
	{
		Vector<CourseBean> vdo=null;
		
		
		try{
			
			vdo=new Vector<CourseBean>();
			
				stmt1=con.createStatement();
				rs1=stmt1.executeQuery("select coursename,to_char(schedule_date),schedule_time,place,facultyname from schedule");
				while(rs1.next())
				{  
				CourseBean rb=new CourseBean();
							
								rb.setCoursename(rs1.getString(1));
								rb.setDate(rs1.getString(2));
								rb.setTime(rs1.getString(3));
								rb.setArea(rs1.getString(4));
								rb.setUsername(rs1.getString(5));
								vdo.add(rb);
					 }		

		}
catch (SQLException e) {
	e.printStackTrace();
} 
catch(Exception e){
	
	e.printStackTrace();
}

finally
	{
	 try{
		 if(con!=null)
			 con.close();				 
	 }
	 catch(SQLException e){}
	}

return vdo;		
}
	
	public Vector<CourseBean> viewCourseRequest()
	{
		Vector<CourseBean> vdo=null;
		
		
		try{
			
			vdo=new Vector<CourseBean>();
			
				stmt1=con.createStatement();
				rs1=stmt1.executeQuery("select firstname,lastname,coursename,to_char(enroll_date),area,city,district from course,course_enroll,address,userdetails where course.courseid=course_enroll.courseid and course_enroll.userid=address.userid and userdetails.userid=course_enroll.userid");
			while(rs1.next())
				{  
					
					
				CourseBean rb=new CourseBean();
				             	rb.setUsername(rs1.getString(1));
								rb.setLastname(rs1.getString(2));
								rb.setCoursename(rs1.getString(3));
								rb.setDate(rs1.getString(4));
								rb.setArea(rs1.getString(5));
								rb.setCity(rs1.getString(6));
								rb.setDistrict(rs1.getString(7));
								vdo.add(rb);
					 }		

		}
catch (SQLException e) {
	e.printStackTrace();
} 
catch(Exception e){
	
	e.printStackTrace();
}

finally
	{
	 try{
		 if(con!=null)
			 con.close();				 
	 }
	 catch(SQLException e){}
	}

return vdo;		
}
	
	public boolean insertCourseEnroll(int cid,String userid)throws FileNotFoundException{
		 
		 
		 
		boolean flag = false;
		try {
			System.out.println("courseid"+cid+"..."+userid);
			stmt=con.createStatement();
			int i=stmt.executeUpdate("INSERT INTO course_enroll VALUES((select nvl(max(enrollid),0)+1 from course_enroll),(select userid from userdetails where loginid='"+userid+"'),"+cid+",sysdate)");
			if(i>0){
				flag = true;
				con.commit();
			}
			else
			{
				con.rollback();
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean addCourseSchedule(CourseBean cb)throws FileNotFoundException{
		 
		 
		 
		boolean flag = false;
		try {
			String loginid=cb.getUsername();
			String course=cb.getCoursename();
			String date=DateWrapper.parseDate(cb.getDate());
			String time=cb.getTime();
			String place=cb.getArea();
			stmt=con.createStatement();
			int i=stmt.executeUpdate("INSERT INTO schedule VALUES((select nvl(max(scheduleid),0)+1 from schedule),'"+date+"','"+time+"','"+place+"','"+course+"',(select firstname from userdetails where loginid='"+loginid+"'))");
			if(i>0){
				flag = true;
				con.commit();
			}
			else
			{
				con.rollback();
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return flag;
	}
	

}
