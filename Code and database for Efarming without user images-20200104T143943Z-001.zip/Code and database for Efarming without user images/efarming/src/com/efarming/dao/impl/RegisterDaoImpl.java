package com.efarming.dao.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.util.DateWrapper;
import com.efarming.db.SqlConstants;
import com.efarming.db.ConnectionFactory;
import com.efarming.dao.RegisterDaoI;

public class RegisterDaoImpl implements RegisterDaoI{
	
	Connection con;
	PreparedStatement pstmt,pstmt1,pstm1,pstm2,pstm3;
	Statement stmt,stmt1,stmt2,stmt3;
	ResultSet rs,rs1,rs2,rs3;
	
	 public RegisterDaoImpl(){
			
			con=ConnectionFactory.getConnection();
			System.out.println("con"+con);
		}
	
	
	 public boolean checkAvailability(String userid){
		 boolean flag=false;
	    	try{
	    		System.out.println("con"+con);
	    		pstmt=con.prepareStatement(SqlConstants._CHECK_AVAILABILITY);
	    		pstmt.setString(1,userid);
	    		rs=pstmt.executeQuery();
	    		if(rs.next()){
	    			flag=true;
	    		}
	    	}catch(SQLException e){
	    		e.printStackTrace();
	    	}
	    
	
	    finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){
			 
			 e.printStackTrace();
		 }
		}
	return flag;
}
	 
	 public boolean deleteCompprof(String userid){
		 boolean flag=false;
			try{	    		
			
		    	
	        int queid=Integer.parseInt(userid);
	        stmt=con.createStatement();
	        int i=stmt.executeUpdate("delete from userdetails where userid="+userid);
	        if(i>0)
	        {
	         	   flag=true;
		          con.commit();
	         	   }
	       
		         else
		         {
		        	 flag=false;
		        	 con.rollback();
		         }
		    } 
		    catch (SQLException e) 
		    {
		        e.printStackTrace();
		        flag=false;
		    }  
		        catch (Exception se) 
		        {
		            se.printStackTrace();
		        }
		    
		    
		    finally
			{
			 try{
				 if(con!=null)
					 con.close();				 
			 }
			 catch(SQLException e){}
			}
		 return flag;
		 
	}
	 

	 public Vector<RegisterBean> viewProfessional(String path1)
		{
			Vector<RegisterBean> vdo=null;
			
			
			try{
				
			     stmt=con.createStatement();
				rs=stmt.executeQuery("select u.userid,u.firstname,u.lastname,u.email,a.city,a.phone from userdetails u, address a where a.userid=u.userid and u.role='ComputerProfessional'");
				
				vdo=new Vector<RegisterBean>();
				while(rs.next())
				{  
					                RegisterBean rb=new RegisterBean();
									int userid=rs.getInt(1);
									rb.setUid(userid);
									rb.setFirstName(rs.getString(2));
									rb.setLastName(rs.getString(3));
									rb.setEmail(rs.getString(4));
									//Blob b=rs.getBlob(5);
									rb.setCity(rs.getString(5));
									rb.setPhoneNo(rs.getString(6));
									//String path=path1;
									//byte b1[] = b.getBytes(1,(int) b.length());
								   // path=path +"/"+userid+".jpg";
									//OutputStream fout = new FileOutputStream(path);
									//fout.write(b1);
									//rb.setPhoto(path);
									vdo.add(rb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
				
			
			
		}
	 
	 
	 public Vector<RegisterBean> viewStates()
		{
			Vector<RegisterBean> vdo=null;
			
			
			try{
				
			     stmt=con.createStatement();
				rs=stmt.executeQuery("select distinct(state) from address");
				
				vdo=new Vector<RegisterBean>();
				while(rs.next())
				{  
					                RegisterBean rb=new RegisterBean();
									rb.setState(rs.getString(1));
									vdo.add(rb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
				
			
			
		}

	 public Vector<RegisterBean> viewDistricts(String state)
		{
			Vector<RegisterBean> vdo=null;
			
			
			try{
				
			     stmt=con.createStatement();
				rs=stmt.executeQuery("select distinct(district) from address where state='"+state+"'");
				
				vdo=new Vector<RegisterBean>();
				while(rs.next())
				{  
					                RegisterBean rb=new RegisterBean();
									rb.setDistrict(rs.getString(1));
									vdo.add(rb);
						 }		
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
				
			
			
		}

	 public Vector<RegisterBean> viewUserRecord(String state,String dist,String role,String path1)
		{
			Vector<RegisterBean> vdo=null;
			
			
			try{
				
			     stmt=con.createStatement();
				rs=stmt.executeQuery("select firstname,lastname,email,photo,userid from userdetails where role='"+role+"'");
				
				vdo=new Vector<RegisterBean>();
				while(rs.next())
				{  
					int uid=rs.getInt(5);
					stmt1=con.createStatement();
					rs1=stmt1.executeQuery("select phone from address where userid="+uid+" and state='"+state+"' and district='"+dist+"'");
					if(rs1.next())
					{
					                RegisterBean rb=new RegisterBean();
					                rb.setFirstName(rs.getString(1));
					                rb.setLastName(rs.getString(2));
					                rb.setEmail(rs.getString(3));
					                Blob b=rs.getBlob(4);
					                
									String path=path1;
					                byte b1[] = b.getBytes(1,(int) b.length());
								    path=path +"/"+uid+".jpg";
									OutputStream fout = new FileOutputStream(path);
									fout.write(b1);
									rb.setPhoto(path);
					                rb.setUid(uid);
					                rb.setPhoneNo(rs1.getString(1));
									rb.setDistrict(dist);
									rb.setState(state);
									vdo.add(rb);
						 }	
				}
	
			}
	catch (SQLException e) {
		e.printStackTrace();
	} 
	catch(Exception e){
		
		e.printStackTrace();
	}

	finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}

	return vdo;		
				
			
			
		}
 
	 
public boolean registerCitizen(RegisterBean rb)throws FileNotFoundException{
		 
		 
		 
		 int insert=0;	    	
		 boolean flag=true;
			try{	    		
	            pstmt=con.prepareStatement(SqlConstants._INSERT_USERS);	            		    		
	    		System.out.println();
	    		//String photo =rb.getPhoto();
	    		
	    		String dob=DateWrapper.parseDate(rb.getDob());
	    		System.out.println(" in dao dob"+dob);
	    		String fname=rb.getFirstName();
	    		String lname=rb.getLastName();
	    		String squestion=rb.getSquest();
	    		//String role=rb.getRole();
	    		String desig=rb.getDesignation();
	    		String ans=rb.getSecrete();
	    		String email=rb.getEmail();
	    		String phone=rb.getPhoneNo();
	    		String logintype=rb.getRole();
	    	    System.out.println("role"+logintype);
	    		String loginid=rb.getUserName();
	    		String pwd=rb.getPassword();	    			    		
	    		String hno=rb.getHouseNo();
	    		String wardno=rb.getWardNo();
	    		String street=rb.getStreet();
	    		String city=rb.getCity();
	    		String dist=rb.getDistrict();
	    		String state=rb.getState();
	    		String country=rb.getCountry();
	    		String pin=rb.getPin();	
	    		String gender=rb.getGender();
	    		//System.out.println("photo="+photo);
	        	//File f=new File(photo);
	        	//FileInputStream fis=new FileInputStream(f); 
	        	//System.out.println("fole="+f.length());	   
	        	 pstmt.setString(1, loginid);
		         pstmt.setString(2, pwd);  
		         pstmt.setString(3, logintype);
	            pstmt.setString(4, fname);
	            pstmt.setString(5, lname);
	            pstmt.setString(6, dob);
	            pstmt.setString(7,email);
	            pstmt.setString(8, squestion);
	            pstmt.setString(9,ans);
	           
	         // pstmt.setBinaryStream(10, fis,(int)f.length());
	         
	          pstmt.setString(10, gender);
	      
	          int i=pstmt.executeUpdate();
	          
	          if(i>0)
	          {	         	  
	        	  pstmt1=con.prepareStatement(SqlConstants._INSERT_ADDRESS);	        	  	        	  
	        	  pstmt1.setString(1,hno);
	        	  pstmt1.setString(2,street);
	        	  pstmt1.setString(3,city);
	        	  pstmt1.setString(4,dist);
	        	  pstmt1.setString(5,state);
	        	  pstmt1.setString(6,country);
	        	  pstmt1.setString(7,pin);
	        	  pstmt1.setString(8,phone);
	        	  
	        	  insert=pstmt1.executeUpdate();
	        	  }	          	          
	          if(insert>0)
		         {
		         
		          con.commit();
		         }
		         else
		         {
		        	 flag=false;
		        	 con.rollback();
		         }
		    } 
		    catch (SQLException e) 
		    {
		        e.printStackTrace();
		        flag=false;
		        try 
		        {
		            con.rollback();
		        } 
		        catch (SQLException se) 
		        {
		            se.printStackTrace();
		        }
		    } catch (Exception e) {
				// TODO Auto-generated catch block
		    	flag=false;
				e.printStackTrace();
			}
		    
		    finally
			{
			 try{
				 if(con!=null)
					 con.close();				 
			 }
			 catch(SQLException e){}
			}
		 
		 
		 
		 return flag;
		 
	 
	 }
 
public String passwordRecovery(RegisterBean rb){
	String password="nopassword";
    try{
    	
    	 String question=rb.getSquest();
		 String ans=rb.getSecrete();
		 String loginid=rb.getUserName();
		 
		 System.out.println(question+"..."+ans+"...."+loginid);
		
    	pstmt=con.prepareStatement(SqlConstants._RECOVER_PASSWORD);
    	pstmt.setString(1, loginid);
    	pstmt.setString(2, question);
    	pstmt.setString(3, ans);
    	rs=pstmt.executeQuery();
    	if(rs.next()){
    		password=rs.getString(1).trim();
    	}
    }catch(SQLException e){
    	e.printStackTrace();
    }
    
    System.out.println("passworddd..."+password.trim());
	return password;
}

public String passwordChange(RegisterBean rb){
	String password="";
	 String psw="";
    try{
    	
    	 String user=rb.getUserName();
		 String oldpsw=rb.getPassword();
		 String newpsw=rb.getNewpassword();
		
		 System.out.println(user+"..."+oldpsw+"...."+newpsw);
		
    	pstmt=con.prepareStatement("update USERDETAILS set password=? where loginid=? and password=?");
    	pstmt.setString(1,newpsw);
    	pstmt.setString(2,user);
    	pstmt.setString(3,oldpsw);
    	int i=pstmt.executeUpdate();
    	if(i>0){
    		
    		psw=newpsw;
    	}
    }catch(SQLException e){
    	e.printStackTrace();
    }
    
    System.out.println("passworddd..."+password.trim());
	return psw;
}


public String roleCheck(RegisterBean lb)
{
	 
	 String role="";
	 
	 try{
	 
	 
	 System.out.println("in DAo impl is..con is....."+con);
	 
	 pstmt=con.prepareStatement(SqlConstants._CHECK_USER);
	 
	 String uname=lb.getUserid();
	 System.out.println("in Security DAO class.....uname is"+uname);
	 String pwd=lb.getPassword();
	 System.out.println("in Security DAO class.....password is"+pwd);
	 
	 pstmt.setString(1, uname);
	 pstmt.setString(2, pwd);
	 
	 rs=pstmt.executeQuery();
	 
	 
	 while(rs.next())
	 {
		 role=rs.getString(1);
		 
	 }
		 
}
	 catch (SQLException e) {
		 
		
	}
	 
	 finally
		{
		 try{
			 if(con!=null)
				 con.close();				 
		 }
		 catch(SQLException e){}
		}
	 return role;
		

}

}
