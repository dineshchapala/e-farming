package com.efarming.dao;

import java.io.FileNotFoundException;
import java.util.Vector;

import com.efarming.exception.ConnectionException;
import com.efarming.exception.LoginException;
import com.efarming.bean.RegisterBean;

public interface RegisterDaoI {
	
	
	 public boolean checkAvailability(String userid);
	 public boolean registerCitizen(RegisterBean rb)throws FileNotFoundException;
	 public String passwordRecovery(RegisterBean rb);
	 public String passwordChange(RegisterBean rb);
	 public String roleCheck(RegisterBean lb)throws LoginException,ConnectionException;
	 public Vector<RegisterBean> viewProfessional(String path1);
	 public boolean deleteCompprof(String userid);
	 public Vector<RegisterBean> viewStates();
	 public Vector<RegisterBean> viewDistricts(String state);
	 public Vector<RegisterBean> viewUserRecord(String state,String dist,String role,String path1);
}
