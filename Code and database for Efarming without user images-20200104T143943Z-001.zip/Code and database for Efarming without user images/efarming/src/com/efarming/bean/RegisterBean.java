package com.efarming.bean;

public class RegisterBean {
	    private String userid;
		private String userName;
		private String password;
		private String newpassword;
		private String squest;
		private String secrete;
		private String role;
		private String email;
		private String firstName;
		private String lastName;
		private String gender;
		private String dob;
		private String photo;
		private String houseNo;
		private String wardNo;
		private String street;
		private String phoneNo;
		private String district;
		private String state;
		private String country;
		private String pin;
		private String city;
		private String addressid;
		private String addresstype;
		private String designation;
		private String localbodyname;
		private String cropname;
		private int stateid;
		private int distid;
		private int corporationid;
		private int uid;
		
		public String getNewpassword() {
			return newpassword;
		}
		public void setNewpassword(String newpassword) {
			this.newpassword = newpassword;
		}
		public int getStateid() {
			return stateid;
		}
		public void setStateid(int stateid) {
			this.stateid = stateid;
		}
		public int getDistid() {
			return distid;
		}
		public void setDistid(int distid) {
			this.distid = distid;
		}
		public int getCorporationid() {
			return corporationid;
		}
		public void setCorporationid(int corporationid) {
			this.corporationid = corporationid;
		}
		public String getUserid() {
			return userid;
		}
		public void setUserid(String userid) {
			this.userid = userid;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getSquest() {
			return squest;
		}
		public void setSquest(String squest) {
			this.squest = squest;
		}
		public String getSecrete() {
			return secrete;
		}
		public void setSecrete(String secrete) {
			this.secrete = secrete;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getPhoto() {
			return photo;
		}
		public void setPhoto(String photo) {
			this.photo = photo;
		}
		public String getHouseNo() {
			return houseNo;
		}
		public void setHouseNo(String houseNo) {
			this.houseNo = houseNo;
		}
		public String getStreet() {
			return street;
		}
		public void setStreet(String street) {
			this.street = street;
		}
		public String getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}
		public String getDistrict() {
			return district;
		}
		public void setDistrict(String district) {
			this.district = district;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getPin() {
			return pin;
		}
		public void setPin(String pin) {
			this.pin = pin;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getAddressid() {
			return addressid;
		}
		public void setAddressid(String addressid) {
			this.addressid = addressid;
		}
		public String getAddresstype() {
			return addresstype;
		}
		public void setAddresstype(String addresstype) {
			this.addresstype = addresstype;
		}
		public String getWardNo() {
			return wardNo;
		}
		public void setWardNo(String wardNo) {
			this.wardNo = wardNo;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getLocalbodyname() {
			return localbodyname;
		}
		public void setLocalbodyname(String localbodyname) {
			this.localbodyname = localbodyname;
		}
		public int getUid() {
			return uid;
		}
		public void setUid(int uid) {
			this.uid = uid;
		}
		public String getCropname() {
			return cropname;
		}
		public void setCropname(String cropname) {
			this.cropname = cropname;
		}
		
		

	}
