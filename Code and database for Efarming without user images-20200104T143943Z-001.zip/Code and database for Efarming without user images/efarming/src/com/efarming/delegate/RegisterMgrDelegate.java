package com.efarming.delegate;
import java.io.FileInputStream;
import java.util.Vector;

import com.efarming.exception.LoginException;
import com.efarming.exception.DataNotFoundException;
import com.efarming.bean.CourseBean;
import com.efarming.bean.CropBean;
import com.efarming.bean.RegisterBean;
import com.efarming.exception.ConnectionException;
import com.efarming.servicei.CourseServiceI;
import com.efarming.servicei.CropsServiceI;
import com.efarming.servicei.RegisterServiceI;
import com.efarming.serviceimpl.CourseServiceImpl;
import com.efarming.serviceimpl.CropsServiceImpl;
import com.efarming.serviceimpl.RegisterServiceImpl;

public class RegisterMgrDelegate {
	
	RegisterServiceI rsi=new RegisterServiceImpl();
	CropsServiceI csi=new CropsServiceImpl();
	CourseServiceI cssi=new CourseServiceImpl();
	Vector<CropBean> vdo=null;
	public boolean checkAvailability(String userid)throws ConnectionException{
		 
		 return rsi.checkAvailability(userid);
		 
	 }
	
	public boolean registerCitizen(RegisterBean rb)throws ConnectionException{
		
		return rsi.registerCitizen(rb);
		 
	 }
	
	public boolean addCrop(String name,FileInputStream fileInputStream, int length)throws ConnectionException{
		
	   
			return csi.addCrop(name,fileInputStream,length);
			 
		 }
	
	public boolean addCropQuantity(CropBean cb)throws ConnectionException{
		
		   
		return csi.addCropQuantity(cb);
		 
	 }
	
	public boolean addWholesalerOrder(CropBean cb)throws ConnectionException{
		
		   
		return csi.addWholesalerOrder(cb);
		 
	 }
	public Vector<RegisterBean> addWholesalerTransaction(CropBean cb)throws ConnectionException{
		
		   
		return csi.addWholesalerTransaction(cb);
		 
	 }
	
	
	public boolean updateCropQuantity(CropBean cb)throws ConnectionException{
		
		   
		return csi.updateCropQuantity(cb);
		 
	 }
	public boolean addCourse(String name)throws ConnectionException{
		
		   
		return csi.addCourse(name);
		 
	 }
	public boolean insertCourseEnroll(int cid,String userid)throws ConnectionException{
		
		   
		return cssi.insertCourseEnroll(cid,userid);
		 
	 }
	public boolean addCourseSchedule(CourseBean cb)throws ConnectionException{
		
		   
		return cssi.addCourseSchedule(cb);
		 
	 }
	
	public boolean deleteCrop(String cropid)throws ConnectionException{
		
		return csi.deleteCrop(cropid);
	}
 public boolean deleteCropQuantity(String cropid)throws ConnectionException{
		
		return csi.deleteCropQuantity(cropid);
	}
	
   public boolean deleteCourse(String courseid)throws ConnectionException{
		
		return csi.deleteCourse(courseid);
	}
	
   public boolean deleteCompprof(String userid)throws ConnectionException{
		
		return rsi.deleteCompprof(userid);
	}
	
	public String passwordRecovery(RegisterBean rb)throws DataNotFoundException{
		 
		 String user=rb.getUserName();
		 return rsi.passwordRecovery(rb);
	 }
	public String passwordChange(RegisterBean rb)throws DataNotFoundException{
		 
		 //String user=rb.getUserName();
		 return rsi.passwordChange(rb);
	 }
    public String roleCheck(RegisterBean lb)throws LoginException,ConnectionException{
		
		return rsi.roleCheck(lb);
		}
	public Vector<CropBean> viewCrop(String path1)throws ConnectionException,DataNotFoundException
	{
		return csi.viewCrop(path1);
	}
	public Vector<CropBean> viewCrop()throws ConnectionException,DataNotFoundException
	{
		return csi.viewCrop();
	}
	public Vector<CropBean> viewCropQuantity(String loginid)throws ConnectionException,DataNotFoundException
	{
		return csi.viewCropQuantity(loginid);
	}
	
	public Vector<CropBean> viewCropQuantity(RegisterBean rb)throws ConnectionException,DataNotFoundException
	{
		return csi.viewCropQuantity(rb);
	}
	
	public Vector<CourseBean> viewCourse()throws ConnectionException,DataNotFoundException
	{
		return csi.viewCourse();
	}
	
	public Vector<CourseBean> viewCourse(String user)throws ConnectionException,DataNotFoundException
	{
		return cssi.viewCourse(user);
	}
	public Vector<CourseBean> viewSchedule()throws ConnectionException,DataNotFoundException
	{
		return cssi.viewSchedule();
	}
	public Vector<CourseBean> viewCourseRequest()throws ConnectionException,DataNotFoundException
	{
		return cssi.viewCourseRequest();
	}
	
	public Vector<RegisterBean> viewProfessional(String path1)throws ConnectionException,DataNotFoundException
	{
		return rsi.viewProfessional(path1);
	}
	
	public Vector<RegisterBean> viewStates()throws ConnectionException,DataNotFoundException
	{
		return rsi.viewStates();
	}
	
	public Vector<RegisterBean> viewDistricts(String state)throws ConnectionException,DataNotFoundException
	{
		return rsi.viewDistricts(state);
	}
	
	public Vector<CropBean> viewPurchaseDetails(String loginid)throws ConnectionException,DataNotFoundException
	{
		return csi.viewPurchaseDetails(loginid);
	}
	
	public Vector<CropBean> viewSalesDetails(String loginid)throws ConnectionException,DataNotFoundException
	{
		return csi.viewSalesDetails(loginid);
	}
	
	public Vector<RegisterBean> viewUserRecord(String state,String dist,String role,String path1)throws ConnectionException,DataNotFoundException
	{
		return rsi.viewUserRecord(state,dist,role,path1);
	}
}
