package com.efarming.exception;

public class ConnectionException extends Exception {

	
	private static final long serialVersionUID = -6256717472813064682L;

	public ConnectionException() {
		
	}

	public ConnectionException(String arg0) {
		super(arg0);
		
	}	

}
