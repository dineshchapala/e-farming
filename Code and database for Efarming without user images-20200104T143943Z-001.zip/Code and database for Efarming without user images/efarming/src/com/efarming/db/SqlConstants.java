package com.efarming.db;

public class SqlConstants {
	
	 public static final String _CHECK_AVAILABILITY="select userid from userdetails where loginid=?";
	 public static final String _INSERT_USERS="insert into userdetails values((select nvl(max(userid),1000)+1 from userdetails),?,?,?,?,?,?,?,?,?,?)"; 
	 public static final String _INSERT_ADDRESS="insert into address values((select max(userid) from userdetails),(select nvl(max(addressid),1000)+1 from address),?,?,?,?,?,?,?,?)";
	 public static final String _RECOVER_PASSWORD="select password from userdetails where loginid=? and forgotquestion=? and forgotanswer=?";
	 public static final String _CHECK_USER="select role from userdetails where loginid=? and password=?";
	 
}
